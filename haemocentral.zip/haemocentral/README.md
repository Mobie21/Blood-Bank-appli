# HaemoCentral

National blood availability platform. One repo, one command.

```
haemocentral/
├── frontend/   React + TanStack Start + Tailwind + shadcn/ui
├── backend/    Express + TypeScript + MongoDB (Mongoose) + Zod + JWT
├── docs/       API spec
└── package.json  (root scripts run both together)
```

## Run it

```bash
npm run setup     # installs root + backend + frontend, creates .env files
# edit backend/.env: set MONGODB_URI (MongoDB Atlas) and both JWT secrets
npm run seed      # optional: demo institutions, users and stock
npm run dev       # starts API (port 4000) and web app together
```

- API: http://localhost:4000/api/v1  (health: http://localhost:4000/health)
- Web app: the URL Vite prints (usually http://localhost:8080)
- Stop both with Ctrl+C.

## Other commands

| Command | What it does |
|---|---|
| `npm run build` | Builds backend and frontend |
| `npm run start` | Runs the built backend and frontend preview together |
| `npm run seed` | Loads demo data |
| `npm run typecheck` | Type-checks the backend |

## Demo logins (after `npm run seed`, password = `SEED_DEFAULT_PASSWORD`, default `Password123!`)

| Role | Email |
|---|---|
| Super Admin | admin@haemocentral.co.zw |
| Hospital Admin | admin@parirenyatwa.co.zw |
| Staff | staff@parirenyatwa.co.zw |

If the web app runs on a port other than 8080, 3000 or 5173, add it to `CORS_ORIGIN` in `backend/.env`.
