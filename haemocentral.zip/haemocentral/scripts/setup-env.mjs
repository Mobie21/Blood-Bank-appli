// Creates backend/.env and frontend/.env from the examples if they don't exist yet.
import { copyFileSync, existsSync } from "node:fs";
for (const dir of ["backend", "frontend"]) {
  const env = `${dir}/.env`, ex = `${dir}/.env.example`;
  if (!existsSync(env) && existsSync(ex)) {
    copyFileSync(ex, env);
    console.log(`Created ${env} from ${ex}`);
  }
}
console.log("\nNext: edit backend/.env (MONGODB_URI + both JWT secrets), then run: npm run dev");
